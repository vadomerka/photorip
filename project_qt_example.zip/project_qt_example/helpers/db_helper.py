# import os
# import sys
#
# current = os.path.dirname(os.path.realpath(__file__))
# # Getting the parent directory name
# # where the current directory is present.
# parent = os.path.dirname(current)
# # adding the parent directory to
# # the sys.path.
# sys.path.append(parent)

from CONSTS import PATH_TO_DB
import sqlite3


class DbHelper:
    def __init__(self):
        # При создании класса надо создать подключение к БД
        self.connection = sqlite3.connect(PATH_TO_DB)

    def request(self, request, params=None):
        # Вернёт True, если всё окей, если будут ошибки - вернёт False
        try:
            cursor = self.connection.cursor()
            if not params:
                cursor.execute(request)
            else:
                cursor.execute(request, params)
            self.connection.commit()
            return True
        except Exception as ex:
            print(ex)
            return False

    def query(self, query, params=None, isAll=True, isOne=False, howMany=None):
        # Вернёт результат выполнения запроса, если всё окей, если будут ошибки - вернёт None
        try:
            cursor = self.connection.cursor()
            if not params:
                result = None
                if isAll:
                    result = cursor.execute(query).fetchall()
                elif isOne:
                    result = cursor.execute(query).fetchone()
                elif howMany:
                    result = cursor.execute(query).fetchmany(howMany)
                return result
            else:
                result = None
                if isAll:
                    result = cursor.execute(query, params).fetchall()
                elif isOne:
                    result = cursor.execute(query, params).fetchone()
                elif howMany:
                    result = cursor.execute(query, params).fetchmany(howMany)
                return result
        except Exception as ex:
            print(ex)
            return None

    def __del__(self):
        # Когда класс перестаёт использоваться, то надо подключение закрыть
        self.connection.close()
