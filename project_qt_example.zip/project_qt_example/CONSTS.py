# Переменная для пути до базы данных
PATH_TO_DB = "./example.db"