# import os
# import sys
#
# current = os.path.dirname(os.path.realpath(__file__))
# # Getting the parent directory name
# # where the current directory is present.
# parent = os.path.dirname(current)
# # adding the parent directory to
# # the sys.path.
# sys.path.append(parent)

from uis.enter_window import Ui_MainWindow
from helpers.db_helper import DbHelper
from logic.register import Register
import sys

from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox


class Enter(QMainWindow, Ui_MainWindow):
    def __init__(self, main_window):
        super().__init__()
        self.setupUi(self)

        self.register_window = None
        self.main_window = main_window
        self.pushButton.clicked.connect(self.enter)
        self.pushButton_2.clicked.connect(self.register)

    def enter(self):
        login = self.lineEdit.text()
        password = self.lineEdit_2.text()
        db_helper = DbHelper()
        # Сделать запрос на получение логина и пароля
        result = db_helper.query(
            "SELECT id FROM users WHERE login=? AND password=?",
            params=(login, password),
            isAll=False,
            isOne=True
        )
        if result:
            self.main_window.set_user(result[0])
            self.close()
        else:
            # Сказать пользователю, что произошло ошибка
            msgBox = QMessageBox()
            msgBox.setIcon(QMessageBox.Information)
            msgBox.setText("Возможно неверный логин или пароль")
            msgBox.setWindowTitle("Ошибка")
            msgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
            msgBox.exec_()

    def register(self):
        self.register_window = Register(self)
        self.register_window.show()
        self.hide()

    def closeEvent(self, event):
        if self.main_window:
            self.main_window.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Enter(None)
    ex.show()
    sys.exit(app.exec_())
