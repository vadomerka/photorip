# import os
# import sys
#
# current = os.path.dirname(os.path.realpath(__file__))
# # Getting the parent directory name
# # where the current directory is present.
# parent = os.path.dirname(current)
# # adding the parent directory to
# # the sys.path.
# sys.path.append(parent)

from helpers.db_helper import DbHelper
from uis.register import Ui_MainWindow

from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox


class Register(QMainWindow, Ui_MainWindow):
    def __init__(self, prev_window):
        super().__init__()
        self.setupUi(self)
        self.prev_window = prev_window
        self.pushButton.clicked.connect(self.register)

    def register(self):
        login = self.lineEdit.text()
        password = self.lineEdit_2.text()
        db_helper = DbHelper()
        # Сделать запрос на получение логина и пароля
        result = db_helper.query(
            "SELECT * FROM users WHERE login=? AND password=?",
            params=(login, password)
        )
        if result:
            msgBox = QMessageBox()
            msgBox.setIcon(QMessageBox.Information)
            msgBox.setText("Такой пользователь уже есть")
            msgBox.setWindowTitle("Ошибка")
            msgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
            msgBox.exec_()
        else:
            try:
                result = db_helper.request(
                    "INSERT INTO users(login, password) VALUES (?, ?)",
                    params=(login, password)
                )
                if result:
                    self.close()
                else:
                    raise Exception("Произошла ошибка при создании пользователя!")
            except Exception as ex:
                print(ex)
                msgBox = QMessageBox()
                msgBox.setIcon(QMessageBox.Information)
                msgBox.setText("Проверьте логи")
                msgBox.setWindowTitle("Ошибка")
                msgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
                msgBox.exec_()
                return

    def closeEvent(self, event):
        if self.prev_window:
            self.prev_window.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Register(None)
    ex.show()
    sys.exit(app.exec_())
