from helpers.db_helper import DbHelper
from uis.main import Ui_MainWindow
from logic.enter import Enter

import sys
import traceback
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox


class Main(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.make_error)

        self.login = None
        self.enter_window = Enter(self)
        self.enter_window.show()
        self.hide()

    def set_user(self, id):
        db_helper = DbHelper()
        result = db_helper.query(
            "SELECT login, bio FROM users WHERE id=?",
            params=(id,)
        )
        if result:
            self.login = result[0][0]
            bio = result[0][1]
            self.lineEdit.setText(self.login)
            self.textEdit.setPlainText(bio if bio else "Нет био")
        else:
            # Сказать пользователю, что произошло ошибка
            msgBox = QMessageBox()
            msgBox.setIcon(QMessageBox.Information)
            msgBox.setText("Произошла ошибка, проверьте логи")
            msgBox.setWindowTitle("Ошибка")
            msgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
            msgBox.exec_()

    def make_error(self):
        raise Exception("Super error")

    def show(self):
        if not self.login:
            self.close()
        else:
            super().show()


def excepthook(exc_type, exc_value, exc_tb):
    tb = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    print("error catched!:")
    print("error message:\n", tb)
    msgBox = QMessageBox()
    msgBox.setIcon(QMessageBox.Information)
    msgBox.setText("Произошла непредвиденная серьезная ошибка, проверьте логи")
    msgBox.setWindowTitle("Ошибка")
    msgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
    msgBox.exec_()


sys.excepthook = excepthook

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Main()
    sys.exit(app.exec_())
